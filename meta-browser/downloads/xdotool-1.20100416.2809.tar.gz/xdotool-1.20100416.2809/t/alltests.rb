require 'test/unit/testsuite'
require 'test_basic'
require 'test_search'
require 'test_window'
