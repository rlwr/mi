#ifndef _VERSION_H_
#define _VERSION_H_
static const char *XDO_VERSION = "1.20100416.2809";
#endif /* ifndef _VERSION_H */
