#define HAVE_ASSERT_H 1
